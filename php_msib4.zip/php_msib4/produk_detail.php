
<?php
//tangkap request id produk di url
$id = $_REQUEST['id'];
$objProduk = new Produk();
$rs = $objProduk->getProduk($id);
?>

<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                    <div class="card">
                    <img src="assets/img/<?= $rs['foto'];?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?= $rs['nama'];?></h5>
                            <table class="table table-hover">
                                <tr>
                                <td>Kode Produk</td>
                                <td>: </td>
                                <td><?= $rs['kode'];?></td>
                                </tr>
                                <tr>
                                <td>Harga Produk</td>
                                <td>: </td>
                                <td>Rp. <?= number_format($rs['harga'],0,',','.') ;?></td>
                                </tr>
                                <tr>
                                <td>Stok</td>
                                <td>: </td>
                                <td><?= $rs['stok'];?></td>
                                </tr>
                                <tr>
                                <th>Jenis Produk</th>
                                <th>: </th>
                                <th><?= $rs['kategori'];?></th>
                                </tr>
                            </table>
                            <hr>
                            <a href="index.php?hal=produk" class="btn btn-primary">
								<i class="bi bi-arrow-left"></i> Go Back
							</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>