<?php
$member = $_SESSION['MEMBER'];
$role = $member['role'];
if(isset($member) && ($role == 'admin' || $role == 'staff')){
// buat objek dari class Suplai_barang
$objSuplai_barang = new Suplai_barang();
$rs = $objSuplai_barang->index();
?>
<h3>Daftar Suplai_barang</h3>
<a href="index.php?hal=suplai_barang_form" class="btn btn-primary">
    <i class="bi bi-plus-circle-fill"></i> Tambah</a>
<table class="table table-hover datatable">
	<thead>
		<tr>
            <th>No</th>
            <th>kode_suplai</th>
            <th>Tanggal</th>
            <th>Supplier</th>
            <th>Produk</th>
            <th>Action</th>
        </tr>
	</thead>
	<tbody>
		<?php
		$no = 1;
		foreach ($rs as $data) {
		?>
		<tr>
			<th><?= $no ?></th>
			<td><?= $data['kode_suplai']?></td>
			<td><?= date('d M Y',strtotime($data['tgl']))?></td>
			<td><?= $data['supplier']?></td>
            <td><?= $data['produk']?></td>
			<td>
				<form method="POST" action="Suplai_barangController.php">
				<a class="btn btn-info" href="index.php?hal=suplai_barang_detail&id=<?= $data['id'] ?>" title="detail">
					<i class="bi bi-eye-fill"></i>
			    </a>

                <a class="btn btn-warning" href="index.php?hal=suplai_barang_form&idedit=<?= $data['id'] ?>" title="ubah">		
					<i class="bi bi-pencil-fill"></i>
				</a>
				<!-- hapus data -->
            	<?php if($role == 'admin'){ ?>
				<button class="btn btn-danger" type="submit" title="Hapus"
						name="proses"value="hapus"
						onclick="return confirm('Anda Yakin Data Dihapus?')">		
				<i class="bi bi-trash-fill"></i>
				</button>
				<input type="hidden" name="idx" value="<?= $data['id'] ?>" />
				<?php } ?>
				</form>
			</td>
		</tr>
		<?php
		$no++;
		} ?>
	</tbody>
</table>
<?php
}
else{
	include_once 'acess_denied.php';
	//header('location:index.php?hal=home');

}
?>