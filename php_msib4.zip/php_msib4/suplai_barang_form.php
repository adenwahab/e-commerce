<?php
//tangkap request idedit untuk edit
$idedit = $_REQUEST['idedit'];
//lihat di url apakah ada requestan idedit
if(!empty($idedit)){ //-----------modus edit data lama------------
	$model = new Suplai_barang();
	//tampilkan data lama di seluruh element form
	$row = $model->getSuplai_barang($idedit);
}
else{//-----------modus entry data baru------------
	$row = []; //form tetap dalam keadaan kosong
}

//print_r('<h1>'.$rs['harga'].'</h1>');

?>

<h3>Order</h3>
<div class="container px-5 my-5">
    <form method="POST" action="Suplai_barangController.php" id="contactForm" data-sb-form-api-token="API_TOKEN">
        <div class="form-floating mb-3">
            <input class="form-control" name="kode_suplai" value="<?= $row['kode_suplai']?>" id="kodeSuplai" type="text" placeholder="Kode Suplai" data-sb-validations="required" />
            <label for="kodeSuplai">Kode Suplai</label>
            <div class="invalid-feedback" data-sb-feedback="kodeSuplai:required">Kode Suplai is required.</div>
        </div>

        <div class="form-floating mb-3">
            <input class="form-control" name="tgl" value="<?= $row['tgl']?>" id="tanggalSuplai" type="date" placeholder="tanggal Suplai" data-sb-validations="required" />
            <label for="tanggalSuplai">Tanggal Suplai</label>
            <div class="invalid-feedback" data-sb-feedback="tanggalSuplai:required">tanggal Suplai is required.</div>
        </div>
        
        <div class="form-floating mb-3">
            <select name="supplier" id="Supplier" data-sb-validations="required" class="form-select">
                <option value="" disabled selected> -- Pilih --</option>
            <?php
                $objSupplier = new Supplier();
                $rs = $objSupplier->index();
                foreach ($rs as $pl) { 
                    $cek = ($pl['id'] == $row['supplier_id']) ? 'selected' : '';
                ?>	
                <option value="<?= $pl['id']?>" <?= $cek ?> ><?= $pl['nama'] ?></option>
            <?php } ?>
            </select>
            <label for="Supplier">Supplier</label>
            <div class="invalid-feedback" data-sb-feedback="Supplier:required">Supplier is required.</div>
        </div>

        <div class="form-floating mb-3">
            <select name="produk" id="Produk" data-sb-validations="required" class="form-select">
            <option value="" disabled selected> -- Pilih --</option>
                <?php
                    $objProduk = new Produk();
                    $data = $objProduk->index();

                    foreach ($data as $pk) { 
                        $cek = ($pk['id'] == $row['produk_id']) ? 'selected' : ''; 
                    ?>
                    <option value="<?= $pk['id']?>" <?= $cek ?> ><?= $pk['nama'] ?></option>
                    <?php } ?>
            </select>
            <label for="Produk">Produk</label>
            <div class="invalid-feedback" data-sb-feedback="Produk:required">Produk is required.</div>
        </div>
        <div class="form-floating mb-3">
            <input class="form-control" name="jumlah" value="<?= $row['jumlah']?>" id="jumlahSuplai" type="number" placeholder="jumlah Suplai" data-sb-validations="required" />
            <label for="jumlahSuplai">Jumlah</label>
            <div class="invalid-feedback" data-sb-feedback="jumlahSuplai:required">jumlah Suplai is required.</div>
        </div>
        <div class="form-floating mb-3">
            <textarea class="form-control" name="ket" id="keterangan" rows="10" placeholder="Keterangan" data-sb-validations="required" style="height: 150px"><?= $row['keterangan']?></textarea>
            <label for="keterangan">Keterangan</label>
            <div class="invalid-feedback" data-sb-feedback="keterangan:required">keterangan is required.</div>
        </div>


        <?php 
        if(empty($idedit)){ //-----------modus entry data baru------------
        ?>
        	<button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
        <?php
    	}
        else{ //-----------modus edit data lama------------
        ?>
        <button class="btn btn-warning" name="proses" value="ubah" id="ubah" type="submit">Ubah</button>
        <input type="hidden" name="idedit" value="<?= $idedit ?>" />
        <?php
    	}
    	?>
        <button class="btn btn-info" name="proses" value="batal" id="batal" type="submit">Batal</button>
        
    </form>
</div>
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>