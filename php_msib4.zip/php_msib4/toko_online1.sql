-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 20 Bulan Mei 2023 pada 18.50
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `toko_online1`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis`
--

CREATE TABLE `jenis` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `jenis`
--

INSERT INTO `jenis` (`id`, `nama`) VALUES
(2, 'elektronik'),
(1, 'furniture'),
(8, 'makanan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `member`
--

CREATE TABLE `member` (
  `id` int(11) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role` enum('admin','staff','pelanggan','suplier') DEFAULT NULL,
  `join_date` datetime DEFAULT current_timestamp(),
  `foto` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `member`
--

INSERT INTO `member` (`id`, `fullname`, `email`, `password`, `role`, `join_date`, `foto`) VALUES
(1, 'admin', 'admin@gmail.com', '17c651e4794391828b2ac12e46fc24554eda3371', 'admin', '2023-05-15 10:06:52', 'admin.jpg'),
(3, 'budi', 'budi@gmail.com', 'e02050d7ad828c6a0fbdf870795d2b3eb3dd15d2', 'pelanggan', '2023-05-15 10:06:52', 'budi.jpg'),
(4, 'wahab', 'wahab@gmail.com', '32498d8096223762dcebbaf518ef427180b093bb', 'staff', '2023-05-16 01:36:09', 'wahab.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `alamat` text NOT NULL,
  `hp` varchar(15) NOT NULL,
  `email` varchar(45) NOT NULL,
  `foto` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id`, `nama`, `alamat`, `hp`, `email`, `foto`) VALUES
(1, 'Wahab', 'Jl. Raya No. 123', '081234567890', 'wahab@mail.com', 'wahab.jpg'),
(2, 'Aura', 'Jl. Suci No. 45', '081234567891', 'aura@mail.com', 'aura.jpg'),
(3, 'Budi Darsono', 'jl. sukasenang', '087654319721', 'budi@gmail.com', 'budi.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id` int(11) NOT NULL,
  `kode` char(5) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `pelanggan_id` int(11) NOT NULL,
  `tgl` datetime NOT NULL DEFAULT current_timestamp(),
  `jumlah` varchar(45) NOT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id`, `kode`, `produk_id`, `pelanggan_id`, `tgl`, `jumlah`, `keterangan`) VALUES
(1, 'PD001', 1, 1, '2023-05-05 10:17:36', '4', NULL),
(4, 'AC010', 7, 1, '2023-05-18 00:00:00', '2', 'di kirim ke rumah'),
(5, 'BGR02', 11, 2, '2023-05-18 00:00:00', '2', 'order gojek'),
(10, 'AC013', 3, 2, '2023-05-19 00:00:00', '3', 'kirim ke rumah'),
(11, 'HP004', 6, 3, '2023-05-19 00:00:00', '1', 'Gress');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id` int(11) NOT NULL,
  `kode` char(5) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `jenis_id` int(11) NOT NULL,
  `harga` double NOT NULL,
  `stok` int(11) NOT NULL,
  `foto` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `kode`, `nama`, `jenis_id`, `harga`, `stok`, `foto`) VALUES
(1, 'PD001', 'Meja', 1, 1000000, 6, 'meja.jpg'),
(2, 'PD002', 'Kursi', 1, 500000, 25, 'kursi1.jpg'),
(3, 'PD003', 'Lemari', 1, 2000000, 5, 'lemari.jpg'),
(4, 'PD004', 'TV', 2, 6000000, 3, 'tv.jpg'),
(5, 'PD005', 'Laptop', 2, 8000000, 32, 'laptop1.jpg'),
(6, 'PD006', 'HP', 2, 5000000, 15, 'iphone.jpg'),
(7, 'AC007', 'AC', 2, 2000000, 11, 'ac.jpg'),
(8, 'LP008', 'Lemari Pakaian', 1, 4000000, 10, 'lemaripakaian.jpg'),
(9, 'MB001', 'Meja Belajar', 1, 2500000, 10, 'meja_belajar.jpg'),
(11, 'BGR01', 'Burger', 8, 50000, 50, 'burger.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplai_barang`
--

CREATE TABLE `supplai_barang` (
  `id` int(11) NOT NULL,
  `kode_suplai` char(5) NOT NULL,
  `tgl` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `produk_id` int(11) NOT NULL,
  `jumlah` varchar(45) NOT NULL,
  `keterangan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `supplai_barang`
--

INSERT INTO `supplai_barang` (`id`, `kode_suplai`, `tgl`, `supplier_id`, `produk_id`, `jumlah`, `keterangan`) VALUES
(2, 'SPL01', '2023-05-05', 1, 1, '50', 'Pengiriman dari Jakarta'),
(4, 'SPL02', '2023-05-05', 2, 3, '20', 'Pengiriman dari Surabaya'),
(5, 'SPL02', '2023-05-05', 2, 3, '20', 'Pengiriman dari Surabaya'),
(6, 'SPL05', '2023-05-05', 3, 5, '20', 'Pengiriman dari Bandung'),
(7, 'SPL07', '2023-05-18', 3, 5, '4', 'Dikirim dari Bekasi'),
(10, 'SPL08', '2023-05-20', 2, 7, '1', 'sdad'),
(11, 'SPL09', '2023-05-20', 1, 11, '3', 'percob');

--
-- Trigger `supplai_barang`
--
DELIMITER $$
CREATE TRIGGER `normalkanStok` AFTER DELETE ON `supplai_barang` FOR EACH ROW BEGIN
    UPDATE produk SET stok = stok - OLD.jumlah WHERE id = OLD.produk_id;
END #
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tambahStok` AFTER INSERT ON `supplai_barang` FOR EACH ROW BEGIN
    UPDATE produk SET stok = stok + NEW.jumlah WHERE id = NEW.produk_id;
END #
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `updateStok` AFTER UPDATE ON `supplai_barang` FOR EACH ROW BEGIN
    UPDATE produk SET stok = stok - OLD.jumlah + NEW.jumlah WHERE id = NEW.produk_id;
END #
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(15) NOT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `supplier`
--

INSERT INTO `supplier` (`id`, `nama`, `alamat`, `telp`, `email`) VALUES
(1, 'Supplier A', 'Jl. Sudirman No. 10', '081234567890', 'supplierA@gmail.com'),
(2, 'Supplier B', 'Jl. Gatot Subroto No. 20', '082345678901', 'supplierB@gmail.com'),
(3, 'Supplier C', 'Jl. Sukabumi No. 15', '081234598765', 'supplierC@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `jenis`
--
ALTER TABLE `jenis`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nama_UNIQUE` (`nama`);

--
-- Indeks untuk tabel `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `nama_pelanggan_idx` (`nama`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_UNIQUE` (`kode`),
  ADD KEY `fk_produk_has_pelanggan_produk1` (`produk_id`),
  ADD KEY `fk_produk_has_pelanggan_pelanggan1` (`pelanggan_id`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `kode_UNIQUE` (`kode`),
  ADD KEY `nama_produk_idx` (`nama`),
  ADD KEY `fk_produk_jenis` (`jenis_id`);

--
-- Indeks untuk tabel `supplai_barang`
--
ALTER TABLE `supplai_barang`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_supplier_has_produk_supplier1` (`supplier_id`),
  ADD KEY `fk_supplier_has_produk_produk1` (`produk_id`);

--
-- Indeks untuk tabel `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_UNIQUE` (`email`),
  ADD KEY `nama_pelanggan_idx` (`nama`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `jenis`
--
ALTER TABLE `jenis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `member`
--
ALTER TABLE `member`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `supplai_barang`
--
ALTER TABLE `supplai_barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD CONSTRAINT `fk_produk_has_pelanggan_pelanggan1` FOREIGN KEY (`pelanggan_id`) REFERENCES `pelanggan` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_produk_has_pelanggan_produk1` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD CONSTRAINT `fk_produk_jenis` FOREIGN KEY (`jenis_id`) REFERENCES `jenis` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `supplai_barang`
--
ALTER TABLE `supplai_barang`
  ADD CONSTRAINT `fk_supplier_has_produk_produk1` FOREIGN KEY (`produk_id`) REFERENCES `produk` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_supplier_has_produk_supplier1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
