<?php
class Pelanggan{
    //member1 variabel
    private $koneksi;

    //member2 konstruktor
    public function __construct(){
        global $dbh; //panggil instance obj koneksi
        $this->koneksi = $dbh;
    }
    
    //member3 method/fungsi/action
    public function index(){
        $sql = "SELECT * FROM pelanggan"; 
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
    }

    public function getpelanggan($id){
        $sql = "SELECT  * FROM pelanggan WHERE pelanggan.id = ?;";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
    }

    public function simpan($data){
        $sql = "INSERT INTO pelanggan (nama, alamat, hp, email, foto) VALUES (?, ?, ?, ?, ?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }

    public function ubah($data){
        $sql = "UPDATE pelanggan SET nama=?, alamat=?, hp=?, email=?, foto=? WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }

    public function hapus($data){
        $sql = "DELETE FROM pelanggan WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }
}
?>
