<?php
class Supplier{
    //member1 variabel
    private $koneksi;

    //member2 konstruktor
    public function __construct(){
        global $dbh; //panggil instance obj koneksi
        $this->koneksi = $dbh;
    }
    
    //member3 method/fungsi/action
    public function index(){
        $sql = "SELECT * FROM supplier"; 
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
    }

    public function getSupplier($id){
        $sql = "SELECT  * FROM supplier WHERE id = ?;";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
    }

    public function simpan($data){
        $sql = "INSERT INTO supplier (nama, alamat, telp, email) VALUES (?, ?, ?, ?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }

    public function ubah($data){
        $sql = "UPDATE supplier SET nama=?, alamat=?, telp=?, email=? WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }

    public function hapus($data){
        $sql = "DELETE FROM supplier WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
    }
}
?>
