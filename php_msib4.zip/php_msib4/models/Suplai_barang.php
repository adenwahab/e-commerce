<?php
class Suplai_barang{
	//member1 variabel
	private $koneksi;

	//member2 konstruktor
	public function __construct(){
		global $dbh; //panggil instance obj koneksi
		$this->koneksi = $dbh;
	}
	//member3 method/fungsi/action
	public function index(){
		$sql = "SELECT supplai_barang.*, supplier.nama AS supplier, produk.nama AS produk
                FROM supplai_barang
                INNER JOIN supplier ON supplier.id = supplai_barang.supplier_id
                INNER JOIN produk ON produk.id = supplai_barang.produk_id";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
	}

	public function getSuplai_barang($id){
		$sql = "SELECT supplai_barang.*, supplier.nama AS supplier, produk.nama AS produk
                FROM supplai_barang
                INNER JOIN supplier ON supplier.id = supplai_barang.supplier_id
                INNER JOIN produk ON produk.id = supplai_barang.produk_id
                WHERE supplai_barang.id = ?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
	}

	public function simpan($data){
		$sql = "INSERT INTO supplai_barang (kode_suplai,tgl,supplier_id,produk_id,jumlah,keterangan) VALUES
                (?,?,?,?,?,?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	public function ubah($data){
		$sql = "UPDATE supplai_barang 
                SET kode_suplai=?, tgl=?, supplier_id=?, produk_id=?, jumlah=?, keterangan=? 
                WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	
	public function hapus($data){
			$sql = "DELETE FROM supplai_barang WHERE id=?";
			//prepare statement PDO
			$ps = $this->koneksi->prepare($sql);
			$ps->execute($data);
		}


}