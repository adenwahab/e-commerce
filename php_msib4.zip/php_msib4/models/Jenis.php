<?php
class Jenis{
	//member1 variabel
	private $koneksi;

	//member2 konstruktor
	public function __construct(){
		global $dbh; //panggil instance obj koneksi
		$this->koneksi = $dbh;
	}
	//member3 method/fungsi/action
	public function index(){
		$sql = "SELECT * FROM jenis";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
	}

	public function getjenis($id){
			$sql = "SELECT  jenis.*,produk.nama, stok, kode,harga,foto
					FROM jenis INNER JOIN produk
					ON jenis.id = produk.jenis_id WHERE jenis.id = ?;";
			//prepare statement PDO
			$ps = $this->koneksi->prepare($sql);
			$ps->execute([$id]);
			$rs = $ps->fetchAll();
			return $rs;
		}

	public function GetJenis2($id){
		$sql="SELECT * FROM jenis WHERE id=?" ;
		$ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
	}

		
	public function simpan($data){
		$sql = "INSERT INTO jenis (nama) VALUES (?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	public function ubah($data){
		$sql = "UPDATE jenis SET nama=? WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	
	public function hapus($data){
			$sql = "DELETE FROM jenis WHERE id=?";
			//prepare statement PDO
			$ps = $this->koneksi->prepare($sql);
			$ps->execute($data);
		}

}