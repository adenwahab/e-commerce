<?php
class Member{
	//member1 variabel
	private $koneksi;

	//member2 konstruktor
	public function __construct(){
		global $dbh; //panggil instance obj koneksi
		$this->koneksi = $dbh;
	}

	public function cekLogin($data){
		$sql = "SELECT * FROM member WHERE
		        email = ? AND password = SHA1(MD5(?))";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
        $rs = $ps->fetch();
        return $rs;
	}
	/*
	//member3 method/fungsi/action
	public function index(){
		$sql = "SELECT produk.*, jenis.nama AS kategori
                FROM produk INNER JOIN jenis
                ON jenis.id = produk.jenis_id
                ORDER BY produk.id DESC"; 
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
	}

	public function getproduk($id){
		$sql = "SELECT produk.*, jenis.nama AS kategori
                FROM produk INNER JOIN jenis
                ON jenis.id = produk.jenis_id WHERE produk.id = ?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
	}

	public function simpan($data){
		$sql = "INSERT INTO produk (kode,nama,jenis_id,harga,stok,foto) VALUES
		        (?,?,?,?,?,?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	public function ubah($data){
		$sql = "UPDATE produk SET kode=?,nama=?,jenis_id=?,
		                        	harga=?,stok=?,foto=? WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	public function hapus($data){
		$sql = "DELETE FROM produk WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}
	*/


}