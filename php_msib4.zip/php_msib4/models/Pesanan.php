<?php
class Pesanan{
	//member1 variabel
	private $koneksi;

	//member2 konstruktor
	public function __construct(){
		global $dbh; //panggil instance obj koneksi
		$this->koneksi = $dbh;
	}
	//member3 method/fungsi/action
	public function index(){
		$sql = "SELECT pesanan.*, pelanggan.nama AS pelanggan, produk.nama AS produk
                FROM pesanan
                INNER JOIN pelanggan 
                ON pelanggan.id = pesanan.pelanggan_id
                INNER JOIN produk 
                ON produk.id = pesanan.produk_id ORDER BY pesanan.id DESC"; 
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute();
        $rs = $ps->fetchAll();
        return $rs;
	}

	public function getPesanan($id){
		$sql = "SELECT pesanan.*, 
                        pelanggan.nama AS pelanggan, pelanggan.alamat AS alamat, pelanggan.hp AS telp,
                        produk.nama AS produk, produk.harga AS harga, produk.foto AS foto
                        FROM pesanan
                        INNER JOIN pelanggan 
                        ON pelanggan.id = pesanan.pelanggan_id
                        INNER JOIN produk 
                        ON produk.id = pesanan.produk_id
                        WHERE pesanan.id = ?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute([$id]);
        $rs = $ps->fetch();
        return $rs;
	}

	public function simpan($data){
		$sql = "INSERT INTO pesanan (kode,produk_id,pelanggan_id,tgl,jumlah,keterangan) VALUES
                (?,?,?,?,?,?)";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	public function ubah($data){
		$sql = "UPDATE pesanan SET 
				kode=?,  produk_id=?, pelanggan_id=?, tgl=?, jumlah=?, keterangan=?
				WHERE id=?";
        //prepare statement PDO
        $ps = $this->koneksi->prepare($sql);
        $ps->execute($data);
	}

	
	public function hapus($data){
			$sql = "DELETE FROM pesanan WHERE id=?";
			//prepare statement PDO
			$ps = $this->koneksi->prepare($sql);
			$ps->execute($data);
		}


}