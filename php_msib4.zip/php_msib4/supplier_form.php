<?php
//tangkap request idedit untuk edit
$idedit = $_REQUEST['idedit'];
//lihat di url apakah ada requestan idedit
if(!empty($idedit)){ //-----------modus edit data lama------------
	$model = new Supplier();
	//tampilkan data lama di seluruh element form
	$row = $model->getSupplier($idedit);
}
else{//-----------modus entry data baru------------
	$row = []; //form tetap dalam keadaan kosong
}

//print_r('<h1>'.$rs['harga'].'</h1>');

?>

<h3>Form Supplier</h3>
<div class="container px-5 my-5">
    <form method="POST" action="SupplierController.php" id="contactForm" data-sb-form-api-token="API_TOKEN">
        <div class="form-floating mb-3">
            <input class="form-control" name="nama" value="<?= $row['nama'] ?>" id="Supplier" type="text" placeholder="Supplier" data-sb-validations="required" />
            <label for="Supplier">Supplier</label>
            <div class="invalid-feedback" data-sb-feedback="Supplier:required">Supplier is required.</div>
        </div>


        <div class="form-floating mb-3">
            <input class="form-control" name="alamat" value="<?= $row['alamat'] ?>" id="Supplier" type="text" placeholder="Supplier" data-sb-validations="required" />
            <label for="Supplier">Alamat</label>
            <div class="invalid-feedback" data-sb-feedback="Supplier:required">Alamat is required.</div>
        </div>

        <div class="form-floating mb-3">
            <input class="form-control" name="telp" value="<?= $row['telp'] ?>" id="Supplier" type="text" placeholder="Supplier" data-sb-validations="required" />
            <label for="Supplier">No Handphone</label>
            <div class="invalid-feedback" data-sb-feedback="Supplier:required">No Handphone is required.</div>
        </div>

        <div class="form-floating mb-3">
            <input class="form-control" name="email" value="<?= $row['email'] ?>" id="Supplier" type="text" placeholder="Supplier" data-sb-validations="required" />
            <label for="Supplier">Email</label>
            <div class="invalid-feedback" data-sb-feedback="Supplier:required">Email is required.</div>
        </div>


        <?php 
        if(empty($idedit)){ //-----------modus entry data baru------------
        ?>
        	<button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
        <?php
    	}
        else{ //-----------modus edit data lama------------
        ?>
        <button class="btn btn-warning" name="proses" value="ubah" id="ubah" type="submit">Ubah</button>
        <input type="hidden" name="idedit" value="<?= $idedit ?>" />
        <?php
    	}
    	?>
        <button class="btn btn-info" name="proses" value="batal" id="batal" type="submit">Batal</button>
        
    </form>
</div>
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>