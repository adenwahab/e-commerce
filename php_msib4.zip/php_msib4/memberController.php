<?php
session_start();
//file2 konfigurasi 
require_once 'koneksi.php';
require_once 'models/Member.php';

//tangkap request form login
$email = $_POST['email'];
$password = $_POST['password'];

//simpan variabel di atas ke dalam array
$data = [
	$email, // ? 1
	$password, // ? 2
];

//proses otentikasi user
$tombol = $_POST['proses'];
$model = new Member();
$rs = $model->cekLogin($data);

if(!empty($rs)){ //-----------sukses login-----------------
	$_SESSION['MEMBER'] = $rs;
	header('location:index.php?hal=home');
}
else{ //-----------gagal login-----------------
	echo "<script>
	alert('Maaf User/Password Anda Salah!');
	history.back(); //kembali ke halaman sebelumnya / hal login
	</script>";
}

/* ---------proses CRUD MEMBER----------
switch ($tombol) {
	case 'simpan': $model->simpan($data); break;
	case 'ubah':
		$data[] = $_POST['idedit']; // nambah element array u/ ? ke-7 id
		$model->ubah($data); break;
	case 'hapus':
		unset($data); //hapus semua element array data di atas yg ada 6 ?
		$data = [$_POST['idx']]; // buat array baru u/ where id ? ke-1
		$model->hapus($data); break;
		
	default: header('location:index.php?hal=produk');
}

//jika proses selesai arahkan ke halaman produk
header('location:index.php?hal=produk');
*/