<?php
//file2 konfigurasi 
require_once 'koneksi.php';
require_once 'models/Pelanggan.php';

//tangkap request form
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$hp = $_POST['hp'];
$email = $_POST['email'];
$foto = $_POST['foto'];

//simpan variabel di atas ke dalam array
$data = [
    $nama, // ? 1
    $alamat, // ? 2
    $hp, // ? 3
    $email, // ? 4
    $foto,     // ? 5

];

//proses CRUD
$tombol = $_POST['proses'];
$model = new Pelanggan(); 
switch ($tombol) {
    case 'simpan':
        $model->simpan($data);
        break;
    case 'ubah':
        $data[] = $_POST['idedit']; // nambah element array u/ ? ke-7 id
        $model->ubah($data);
        break;
    case 'hapus':
        unset($data); //hapus semua element array data di atas yg ada 6 ?
        $data = [$_POST['idx']]; // buat array baru u/ where id ? ke-1
        $model->hapus($data);
        break;
    default:
        header('location:index.php?hal=pelanggan');
}

//jika proses selesai, arahkan ke halaman pelanggan
header('location:index.php?hal=pelanggan');

