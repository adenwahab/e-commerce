
<?php
//tangkap request id Pelanggan di url
$id = $_REQUEST['id'];
$objPelanggan = new Pelanggan();
$rs = $objPelanggan->getPelanggan($id);
?>
<div class="card mb-3" style="max-width: 540px;">
	<div class="row g-0">
		<div class="col-md-4">
			<img src="assets/img/<?= $rs['foto'] ?>" class="card-img img-fluid rounded-start"  style="height: 100%;" alt="...">
		</div>
		<div class="col-md-8">
			<div class="card-body">
				<h2 class="card-title"><?= $rs['nama'] ?></h2>
					<table>
						<tr>
							<td>No Handphone</td>
							<td>: </td>
							<td><?= $rs['hp'];?></td>
						</tr>
						<tr>
							<td>Email</td>
							<td>: </td>
							<td><?= $rs['email'];?></td>
						</tr>
						<tr>
							<td>Alamat</td>
							<td>: </td>
							<td><?= $rs['alamat'];?></td>
						</tr>
					</table>
					<hr>
						
				<a href="index.php?hal=Pelanggan" class="btn btn-primary">
					<i class="bi bi-arrow-left"></i> Go Back
				</a>
			</div>
		</div>
	</div>
</div>

