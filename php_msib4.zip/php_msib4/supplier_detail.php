
<?php
//tangkap request id Supplier di url
$id = $_REQUEST['id'];
$objSupplier = new Supplier();
$rs = $objSupplier->getSupplier($id);
?>

<section class="section">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover mt-4">
						<h2 class="card-title"><?= $rs['nama'] ?></h2>
                        <tr>
                            <td>Nama Supplier</td>
                            <td>:</td>
                            <td><?= $rs['nama'] ?></td>
                        </tr>

						<tr>
                            <td>Alamat</td>
                            <td>:</td>
                            <td><?= $rs['alamat'] ?></td>
                        </tr>

                        <tr>
                            <td>No Telp</td>
                            <td>:</td>
                            <td><?= $rs['telp'] ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>:</td>
                            <td><?= $rs['email'] ?></td>
                        </tr>
                    </table>
                    <hr>
						<a href="index.php?hal=Supplier" class="btn btn-primary">
							<i class="bi bi-arrow-left"></i> Go Back
						</a>
                </div>
            </div>
        </div>
    </div>
</section>