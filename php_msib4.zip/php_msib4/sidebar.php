<?php
$sesi = $_SESSION['MEMBER'];
$role = $sesi['role'];
?>

<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="index.php?hal=home">
          <i class="bi bi-house-fill"></i>
          <span>Produk Kami</span>
        </a>
      </li><!-- End Dashboard Nav -->


      <?php
      if(isset($sesi) && ($role == 'admin' || $role == 'staff')){
      ?>

      <li class="nav-heading">Kelola Data</li>

      <li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-database-fill "></i><span>Master Data</span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="index.php?hal=jenis_produk">
              <i class="bi bi-tag" style="font-size: 1rem;"></i><span>Jenis Produk</span>
            </a>
          </li>
          <li>
            <a href="index.php?hal=produk">
              <i class="bi bi-box" style="font-size: 1rem;"></i><span>Produk</span>
            </a>
          </li>
          <li>
            <a href="index.php?hal=pelanggan">
              <i class="bi bi-people" style="font-size: 1rem;"></i><span>Pelanggan</span>
            </a>
          </li>
          <li>
            <a href="index.php?hal=supplier">
              <i  class="bi bi-truck" style="font-size: 1rem;"></i><span>Supplier</span> &nbsp;
              <i class="bi bi-person-check-fill" style="font-size: 1rem;"></i>
          </li>
          
        </ul>
      </li><!-- End Components Nav -->
      
        <li class="nav-heading">Transaksi</li>

        <li class="nav-item">
          <a class="nav-link collapsed" data-bs-target="#forms-nav" data-bs-toggle="collapse" href="#">
            <i class="bi bi-journal-text"></i><span>Transaksi</span><i class="bi bi-chevron-down ms-auto"></i>
          </a>
          <ul id="forms-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
            <li>
              <a href="index.php?hal=pesanan">
                <i class="bi bi-cart-check " style="font-size: 1rem;"></i><span>Pesanan</span>
              </a>
            </li>

            <li>
              <a href="index.php?hal=suplai_barang">
                <i class="bi bi-truck" style="font-size: 1rem;"></i><span>Suplai Barang</span>
              </a>
            </li>
          </ul>
        </li><!-- End Forms Nav -->

        <?php } ?>

        <li class="nav-heading">Informasi & Bantuan</li>
            <a class="nav-link collapsed" href="index.php?hal=contact">
              <i  class="bi bi-box-arrow-in-right"></i>
              <span>Contact</span>
            </a>
          </li><!-- End Contact Page Nav -->
  
            

      <li class="nav-item">


      <?php
      if(!isset($sesi)){
      ?>
      <li class="nav-item">
        <a class="nav-link collapsed" href="login.php">
          <i class="bi bi-box-arrow-in-right"></i>
          <span>Login</span>
        </a>
      </li><!-- End Login Page Nav -->
      <?php } ?>

    </ul>

  </aside>