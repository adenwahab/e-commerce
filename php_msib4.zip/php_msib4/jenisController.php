<?php
//file2 konfigurasi 
require_once 'koneksi.php';
require_once 'models/Jenis.php';

//tangkap request form

$nama = $_POST['nama'];

//simpan variabel di atas ke dalam array
$data = [

	$nama, // ? 2
];

//proses CRUD
$tombol = $_POST['proses'];
$model = new jenis(); 
switch ($tombol) {
	case 'simpan': $model->simpan($data); break;
	case 'ubah':
		$data[] = $_POST['idedit']; // nambah element array u/ ? ke-7 id
		$model->ubah($data); break;
	case 'hapus':
		unset($data); //INI YANG BEDA 1 ; hapus semua element array data di atas yg ada 6 ?
		$data = [$_POST['idx']]; // buat array baru u/ where id ? ke-1
		$model->hapus($data); break;
	default: header('location:index.php?hal=jenis_produk');
}

//jika proses selesai arahkan ke halaman jenis_produk
header('location:index.php?hal=jenis_produk');

