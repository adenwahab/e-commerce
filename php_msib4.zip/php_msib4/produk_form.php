<?php
//tangkap request idedit untuk edit
$idedit = $_REQUEST['idedit'];
//lihat di url apakah ada requestan idedit
if(!empty($idedit)){ //-----------modus edit data lama------------
	$model = new Produk();
	//tampilkan data lama di seluruh element form
	$row = $model->getProduk($idedit);
}
else{//-----------modus entry data baru------------
	$row = []; //form tetap dalam keadaan kosong
}

//print_r('<h1>'.$rs['harga'].'</h1>');

?>

<h3>Form Produk</h3>
<div class="container px-5 my-5">
    <form method="POST" action="ProdukController.php" id="contactForm" data-sb-form-api-token="API_TOKEN">
        <div class="form-floating mb-3">
            <input class="form-control" name="kode" value="<?= $row['kode'] ?>" id="kodeProduk" type="text" placeholder="Kode Produk" data-sb-validations="required" />
            <label for="kodeProduk">Kode Produk</label>
            <div class="invalid-feedback" data-sb-feedback="kodeProduk:required">Kode Produk is required.</div>
        </div>
        <div class="form-floating mb-3">
            <input class="form-control" name="nama" value="<?= $row['nama'] ?>" id="produk" type="text" placeholder="Produk" data-sb-validations="required" />
            <label for="produk">Produk</label>
            <div class="invalid-feedback" data-sb-feedback="produk:required">Produk is required.</div>
        </div>
        <!--div class="mb-3">
            <label class="form-label d-block">Jenis Produk</label>
            <?php
            /*
	        	//ciptakan obj jenis
	        	$objJenis = new Jenis();
	        	$rs = $objJenis->index();
	        	foreach ($rs as $j) {
	        	//edit data jenis
	        	$cek = ($j['id'] == $row['jenis_id']) ? 'checked' : '';	
	        */
            ?>
            <div class="form-check form-check-inline">  	
                <input class="form-check-input" name="jenis" id="<?php // $j['nama'] ?>" type="radio" value="<?php // $j['id'] ?>" 
                data-sb-validations="required" <?php // $cek ?> />
                <label class="form-check-label" for="option"><?php // $j['nama'] ?></label>          
            </div>
            <?php // } ?>
            <div class="invalid-feedback" data-sb-feedback="jenisProduk:required">One option is required.</div>
        </div-->
        <div class="form-floating mb-3">
            <select class="form-select" name="jenis" aria-label="Jenis Produk">
                <option value="">-- Pilih Jenis Produk --</option>
                <?php
                //ciptakan obj jenis
                $objJenis = new Jenis();
                $rs = $objJenis->index();
                foreach ($rs as $j) {
                //edit data jenis
                $sel = ($j['id'] == $row['jenis_id']) ? 'selected' : ''; 
                ?>
                <option value="<?= $j['id'] ?>" <?= $sel ?>><?= $j['nama'] ?></option>
                <?php } ?>
            </select>
            <label for="jenisProduk">Jenis Produk</label>
        </div>
        <div class="form-floating mb-3">
            <input class="form-control" name="harga" value="<?= $row['harga'] ?>" id="harga" type="text" placeholder="Harga" data-sb-validations="required" />
            <label for="harga">Harga</label>
            <div class="invalid-feedback" data-sb-feedback="harga:required">Harga is required.</div>
        </div>
        <div class="form-floating mb-3">
            <input class="form-control" name="stok" value="<?= $row['stok'] ?>" id="stok" type="text" placeholder="Stok" data-sb-validations="required" />
            <label for="stok">Stok</label>
            <div class="invalid-feedback" data-sb-feedback="stok:required">Stok is required.</div>
        </div>
        <div class="form-floating mb-3">
            <input class="form-control" name="foto" value="<?= $row['foto'] ?>" id="foto" type="text" placeholder="Foto" data-sb-validations="required" />
            <label for="foto">Foto</label>
            <div class="invalid-feedback" data-sb-feedback="foto:required">Foto is required.</div>
        </div>

        <?php 
        if(empty($idedit)){ //-----------modus entry data baru------------
        ?>
        	<button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
        <?php
    	}
        else{ //-----------modus edit data lama------------
        ?>
        <button class="btn btn-warning" name="proses" value="ubah" id="ubah" type="submit">Ubah</button>
        <input type="hidden" name="idedit" value="<?= $idedit ?>" />
        <?php
    	}
    	?>
        <button class="btn btn-info" name="proses" value="batal" id="batal" type="submit">Batal</button>
        
    </form>
</div>
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>