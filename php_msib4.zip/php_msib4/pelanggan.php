<?php
$member = $_SESSION['MEMBER'];
$role = $member['role'];
if(isset($member) && ($role == 'admin' || $role == 'staff')){
//buat obj dari class Pelanggan
$objPelanggan = new Pelanggan();
$rs = $objPelanggan->index();
?>
<h3>Pelanggan</h3>
<a href="index.php?hal=Pelanggan_form" class="btn btn-primary">
    <i class="bi bi-plus-circle-fill"></i> Tambah</a>
<table class="table table-hover datatable">
    <thead>
        <tr>
            <th>No</th>
            <th>Nama Pelanggan</th>
            <th>Alamat</th>
            <th>No Handphone</th>
            <th>Email</th>
            <th>Foto</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($rs as $data) {
        ?>
        <tr>
            <td><?= $no ?></td> <!-- fix typo, th -> td -->
            <td><?= $data['nama'] ?></td>
            <td><?= $data['alamat'] ?></td>
            <td><?= $data['hp'] ?></td>
            <td><?= $data['email'] ?></td>
            <td><img src="assets/img/<?= $data['foto'] ?>" width="15%" style="width: 50px;border-radius: 10px;"/></td>
            <td>
                <form method="POST" action="PelangganController.php">
                <a class="btn btn-info" href="index.php?hal=pelanggan_detail&id=<?= $data['id'] ?>" title="detail">
                    <i class="bi bi-eye-fill"></i>
                </a>
                <a class="btn btn-warning" href="index.php?hal=pelanggan_form&idedit=<?= $data['id'] ?>" title="ubah">        
                    <i class="bi bi-pencil-fill"></i>
                </a>
                <!-- hapus data -->
                <?php if($role == 'admin'){ ?>
				<button class="btn btn-danger" type="submit" title="Hapus"
						name="proses"value="hapus"
						onclick="return confirm('Anda Yakin Data Dihapus?')">		
				<i class="bi bi-trash-fill"></i>
				</button>
				<input type="hidden" name="idx" value="<?= $data['id'] ?>" />
				<?php } ?>
                </form>
            </td>
        </tr>
        <?php
        $no++;
        }
        ?>
    </tbody>
</table>
<?php
}
else{
	include_once 'acess_denied.php';
	//header('location:index.php?hal=home');

}
?>
