    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <div class="row row-cols-1 row-cols-md-3 g-4">
          <?php
          //$sql = "SELECT * FROM produk";
          $sql = "SELECT produk.*, jenis.nama AS kategori
                  FROM produk INNER JOIN jenis
                  ON jenis.id = produk.jenis_id";
          $produk = $dbh->query($sql);
          foreach ($produk as $p) {
          ?>  
            <div class="col">
                <div class="card">
                  <img src="assets/img/<?= $p['foto'];?>" class="card-img-top" alt="...">
                  <div class="card-body">
                    <h5 class="card-title"><?= $p['nama'];?></h5>
                    <p class="card-text">
                      <table class="table table-striped">
                        <tr>
                          <td>Kode</td>
                          <td>: </td>
                          <td><?= $p['kode'];?></td>
                        </tr>
                        <tr>
                          <td>Harga</td>
                          <td>: </td>
                          <td>Rp. <?= number_format($p['harga'],0,',','.') ;?></td>
                        </tr>
                        <tr>
                          <td>Stok</td>
                          <td>: </td>
                          <td><?= $p['stok'];?></td>
                        </tr>
                        <tr>
                          <th>Jenis Produk</th>
                          <th>: </th>
                          <th><?= $p['kategori'];?></th>
                        </tr>
                      </table> 
                        <a href="" class="btn btn-primary">
                          <i class="bi bi-cart"></i> Order
                        </a>
                    </p>
                  </div>
                </div>
              </div>
          <?php } ?>  
          </div>

        </div>
      </div>
    </section>
