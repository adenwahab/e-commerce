<?php
//tangkap request idedit untuk edit
$idedit = $_REQUEST['idedit'];
//lihat di url apakah ada requestan idedit
if(!empty($idedit)){ //-----------modus edit data lama------------
	$model = new Jenis();
	//tampilkan data lama di seluruh element form
	$row = $model->GetJenis2($idedit);
}
else{//-----------modus entry data baru------------
	$row = []; //form tetap dalam keadaan kosong
}

//print_r('<h1>'.$rs['harga'].'</h1>');

?>

<h3>Form Jenis</h3>
<div class="container px-5 my-5">
    <form method="POST" action="JenisController.php" id="contactForm" data-sb-form-api-token="API_TOKEN">
        <div class="form-floating mb-3">
            <input class="form-control" name="nama" value="<?= $row['nama'] ?>" id="Jenis" type="text" placeholder="Jenis" data-sb-validations="required" />
            <label for="Jenis">Jenis</label>
            <div class="invalid-feedback" data-sb-feedback="Jenis:required">Jenis is required.</div>
        </div>

        <?php 
        if(empty($idedit)){ //-----------modus entry data baru------------
        ?>
        	<button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
        <?php
    	}
        else{ //-----------modus edit data lama------------
        ?>
        <button class="btn btn-warning" name="proses" value="ubah" id="ubah" type="submit">Ubah</button>
        <input type="hidden" name="idedit" value="<?= $idedit ?>" />
        <?php
    	}
    	?>
        <button class="btn btn-info" name="proses" value="batal" id="batal" type="submit">Batal</button>
        
    </form>
</div>
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>