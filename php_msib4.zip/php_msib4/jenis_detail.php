<div class="d-flex justify-content-start gap-3">
    <?php
    // tangkap request id produk di url
    $id = $_REQUEST['id'];
    $objProduk = new Jenis();
    $rs = $objProduk->getjenis($id);

    foreach ($rs as $data) {
        ?>
        <div class="card" style="width: 18rem;">
            <img src="assets/img/<?= $data['foto'] ?>" class="card-img-top" alt="...">
            <div class="card-body">
                <h5 class="card-title"><?= $data['nama'] ?></h5>
                <table>
                    <section class="section">
                    <tr>
                        <td>Kode Produk</td>
                        <td>:</td>
                        <td><?= $data['kode'] ?></td>
                    </tr>
                    <tr>
                        <td>Harga Produk</td>
                        <td>:</td>
                        <td><?= $data['harga'] ?></td>
                    </tr>
                    <tr>
                        <td>Stok Produk</td>
                        <td>:</td>
                        <td><?= $data['stok'] ?></td>
                    </tr>
                    </section>
                </table>
            </div>
        </div>
        

    <?php
    }
    ?>
</div>
<a href="index.php?hal=jenis_produk" class="btn btn-primary">
    <i class="bi bi-arrow-left"></i> Go Back
</a>
