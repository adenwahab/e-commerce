<?php
session_start();
unset($_SESSION['MEMBER']);
// header('location:index.php?hal=home');
echo "<script>
	alert('Anda Berhasil Logout, silahkan Login Kembali');
    window.location.href='index.php?hal=home';
	</script>";
?> 