<?php
//file2 konfigurasi 
require_once 'koneksi.php';
require_once 'models/Produk.php';

//tangkap request form
$kode = $_POST['kode'];
$nama = $_POST['nama'];
$jenis = $_POST['jenis'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];
$foto = $_POST['foto'];

//simpan variabel di atas ke dalam array
$data = [
	$kode, // ? 1
	$nama, // ? 2
	$jenis, // ? 3
	$harga, // ? 4
	$stok, // ? 5
	$foto, // ? 6
];

//proses CRUD
$tombol = $_POST['proses'];
$model = new Produk(); 
switch ($tombol) {
	case 'simpan': $model->simpan($data); break;
	case 'ubah':
		$data[] = $_POST['idedit']; // nambah element array u/ ? ke-7 id
		$model->ubah($data); break;
	case 'hapus':
		unset($data); //hapus semua element array data di atas yg ada 6 ?
		$data = [$_POST['idx']]; // buat array baru u/ where id ? ke-1
		$model->hapus($data); break;
	default: header('location:index.php?hal=produk');
}

//jika proses selesai arahkan ke halaman produk
header('location:index.php?hal=produk');