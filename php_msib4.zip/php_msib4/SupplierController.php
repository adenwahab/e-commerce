<?php
//file2 konfigurasi 
require_once 'koneksi.php';
require_once 'models/Supplier.php';

//tangkap request form
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$telp = $_POST['telp'];
$email = $_POST['email'];

//simpan variabel di atas ke dalam array
$data = [
    $nama, // ? 1
    $alamat, // ? 2
    $telp, // ? 3
    $email, // ? 4

];

//proses CRUD
$tombol = $_POST['proses'];
$model = new Supplier(); 
switch ($tombol) {
    case 'simpan':
        $model->simpan($data);
        break;
    case 'ubah':
        $data[] = $_POST['idedit']; // nambah element array u/ ? ke-7 id
        $model->ubah($data);
        break;
    case 'hapus':
        unset($data); //hapus semua element array data di atas yg ada 6 ?
        $data = [$_POST['idx']]; // buat array baru u/ where id ? ke-1
        $model->hapus($data);
        break;
    default:
        header('location:index.php?hal=supplier');
}

//jika proses selesai, arahkan ke halaman pelanggan
header('location:index.php?hal=supplier');

