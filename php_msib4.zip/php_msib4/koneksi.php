<?php
/* Connect to a MySQL database using driver invocation */
$dsn = 'mysql:dbname=toko_online1;host=localhost';
$user = 'root';
$password = '';

try {
	$dbh = new PDO($dsn, $user, $password);
	$dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	// print "Sukses Koneksi";
} 
catch(PDOException $e) {
    print "Terjadi Kesalahan: " . $e->getMessage();
    }

?>